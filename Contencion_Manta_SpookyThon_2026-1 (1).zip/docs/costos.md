# Declaración de costos

## Arquitectura desplegada
Sitio estático en AWS Amplify Hosting (alternativa: S3 + CloudFront). La simulación corre en el navegador; no usa Lambda, ECS, SageMaker ni base de datos. Por eso, el número de repeticiones no genera cómputo adicional facturado al servidor.

## Estimación mensual
El costo depende de la región, almacenamiento, transferencia de datos, solicitudes y tarifas vigentes. Para un prototipo académico de bajo tráfico, el costo podría ser bajo, pero **no se declara un importe exacto sin comprobar la calculadora y la factura de la cuenta**.

Para entregar una cifra defendible:
1. Abrir https://calculator.aws/ y seleccionar los servicios realmente desplegados.
2. Estimar un mes de hosting y transferencia con el tráfico esperado.
3. Guardar los supuestos y el resultado aquí.
4. Tras desplegar, revisar AWS Billing/Cost Explorer y registrar el gasto real del evento.

| Concepto | Uso previsto | Costo |
|---|---|---|
| Hosting estático (Amplify o S3 + CloudFront) | Entrega de HTML, CSS y JS | Completar con AWS Pricing Calculator |
| Cómputo de simulación | En navegador del usuario | $0 de cómputo de servidor |
| Base de datos/API | No utilizada | $0 |
| Gasto real del evento | Consultar Billing en la cuenta del equipo | Completar después del despliegue |

**Importante:** las condiciones del plan gratuito y los créditos pueden cambiar; confirmar los beneficios disponibles en https://aws.amazon.com/free/. Configurar un AWS Budget con alerta y adjuntar captura real como `docs/budget.png`. No afirmar que el costo real fue $0 hasta comprobarlo en la cuenta.
