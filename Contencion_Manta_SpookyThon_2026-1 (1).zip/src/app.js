(() => {
"use strict";
const $=id=>document.getElementById(id);
const defaults={pop:300,trans:22,contacts:5,inc:2,inf:6,resources:20,seedZone:"home",seed:2026,runs:"50"};
const sliders=[["pop","popOut",v=>v],["trans","transOut",v=>v+"%"],["contacts","contactsOut",v=>v],["inc","incOut",v=>v],["inf","infOut",v=>v],["resources","resOut",v=>v]];
sliders.forEach(([id,out,fmt])=>$(id).addEventListener("input",()=>$(out).textContent=fmt($(id).value)));
function params(){return {n:+$("pop").value,p:+$("trans").value/100,k:+$("contacts").value,inc:+$("inc").value,inf:+$("inf").value,resources:+$("resources").value,zone:$("seedZone").value,seed:Math.max(1,+$("seed").value||1),runs:+$("runs").value};}
function rng(seed){let a=seed>>>0;return()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
function buildNetwork(n,k,random){const adj=Array.from({length:n},()=>new Set());for(let i=0;i<n;i++){for(let j=0;j<k;j++){let v=Math.floor(random()*n);if(v!==i){adj[i].add(v);adj[v].add(i);}}}return adj;}
function zoneIndex(zone,n){const fraction={home:.08,school:.32,bus:.57,market:.82}[zone]||.08;return Math.min(n-1,Math.floor(n*fraction));}
function simulate(p,mode,seed){
 const rand=rng(seed),n=p.n,adj=buildNetwork(n,p.k,rand);
 const degree=adj.map(a=>a.size),order=Array.from({length:n},(_,i)=>i);
 // Create an initial infected person at the chosen zone, and seed protection only among eligible people.
 const patient=zoneIndex(p.zone,n);
 if(mode==="smart") order.sort((a,b)=>degree[b]-degree[a]||a-b);
 else if(mode==="random") {for(let i=order.length-1;i>0;i--){let j=Math.floor(rand()*(i+1));[order[i],order[j]]=[order[j],order[i]];}}
 const protectedSet=new Set();
 if(mode!=="none") for(const node of order){if(protectedSet.size>=Math.min(p.resources,n-1))break;if(node!==patient)protectedSet.add(node);}
 const state=new Uint8Array(n); // 0 susceptible, 1 exposed, 2 infectious, 3 recovered/immune
 const timer=new Int16Array(n);state[patient]=2;timer[patient]=p.inf;
 let cumulative=1,history=[],day=0;
 while(day<80){
   let counts=[0,0,0,0];for(let i=0;i<n;i++)counts[state[i]]++;history.push(counts);
   if(counts[1]+counts[2]===0)break;
   const newExposed=[];
   for(let i=0;i<n;i++)if(state[i]===2){for(const j of adj[i])if(state[j]===0&&!protectedSet.has(j)&&rand()<p.p)newExposed.push(j);}
   for(const j of newExposed)if(state[j]===0){state[j]=1;timer[j]=p.inc;cumulative++;}
   for(let i=0;i<n;i++){
     if(state[i]===1){timer[i]--;if(timer[i]<=0){state[i]=2;timer[i]=p.inf;}}
     else if(state[i]===2){timer[i]--;if(timer[i]<=0){state[i]=3;}}
   }
   day++;
 }
 let final=[0,0,0,0];for(let i=0;i<n;i++)final[state[i]]++;
 return {cumulative,uninfected:n-cumulative,history,final,days:day};
}
function mean(a){return a.reduce((s,x)=>s+x,0)/Math.max(1,a.length);}
function stats(p,mode){const out=[];for(let r=0;r<p.runs;r++)out.push(simulate(p,mode,(p.seed+r*7919)>>>0));const values=out.map(x=>x.cumulative);return {runs:out,avg:mean(values),low:Math.min(...values),high:Math.max(...values),uninfected:mean(out.map(x=>x.uninfected))};}
function averageHistory(runs){const max=Math.max(...runs.map(r=>r.history.length));return Array.from({length:max},(_,d)=>[0,1,2,3].map(s=>mean(runs.map(r=>r.history[Math.min(d,r.history.length-1)][s]))));}
function draw(hist){const c=$("chart"),ctx=c.getContext("2d"),w=c.width,h=c.height,pad={l:48,r:20,t:22,b:38};ctx.clearRect(0,0,w,h);ctx.fillStyle="#090817";ctx.fillRect(0,0,w,h);const max=Math.max(10,...hist.map(a=>a.reduce((s,v)=>s+v,0)));ctx.font="14px Inter, sans-serif";ctx.strokeStyle="#34264d";ctx.fillStyle="#b7b1c9";ctx.lineWidth=1;
 for(let i=0;i<=4;i++){let y=pad.t+(h-pad.t-pad.b)*i/4;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText(Math.round(max*(1-i/4)),5,y+4);}
 const colors=["#45d6a0","#ffd15c","#ff5e72","#62b5ff"];hist.forEach((_,s)=>{ctx.beginPath();ctx.strokeStyle=colors[s];ctx.lineWidth=3;hist.forEach((a,i)=>{let x=pad.l+(w-pad.l-pad.r)*i/Math.max(1,hist.length-1),y=h-pad.b-(h-pad.t-pad.b)*a[s]/max;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();});ctx.fillStyle="#b7b1c9";ctx.fillText("Día",w/2,h-8);}
function render(){
 const p=params();$("status").textContent="Calculando "+p.runs+" repeticiones por estrategia…";
 // Run synchronously so the demo works without a server or external dependencies.
 const none=stats(p,"none"),random=stats(p,"random"),smart=stats(p,"smart");
 const saved=Math.round(none.avg-smart.avg),reduction=none.avg?Math.round((none.avg-smart.avg)/none.avg*100):0;
 $("saved").textContent=(saved>0?"+":"")+saved;$("infected").textContent=Math.round(smart.avg)+" / "+p.n;$("reduction").textContent=reduction+"%";$("used").textContent=Math.min(p.resources,p.n-1);
 const rows=[["Sin intervenir",none],["Intervención aleatoria",random],["Prioridad por conexiones",smart]];
 $("comparison").innerHTML=rows.map(([name,s])=>`<tr><td>${name}</td><td>${s.avg.toFixed(1)}</td><td>${s.uninfected.toFixed(1)}</td><td>${s.low}–${s.high}</td></tr>`).join("");
 draw(averageHistory(smart.runs));
 let msg;
 if(saved>0&&smart.avg<=random.avg)msg=`<strong>Prioridad sugerida:</strong> proteger primero los nodos con más contactos. En este escenario redujo el promedio en ${saved} contagios frente a no intervenir y obtuvo ${Math.max(0,Math.round(random.avg-smart.avg))} contagios menos que la selección aleatoria. Mantener vigilancia en la zona inicial: ${p.zone}.`;
 else if(saved>0)msg=`<strong>Resultado:</strong> la estrategia priorizada reduce el brote frente a no intervenir en ${saved} casos promedio, pero no supera a la selección aleatoria en este escenario. Conviene probar más recursos o modificar la intervención; no se debe afirmar que una estrategia gana siempre.`;
 else msg=`<strong>Alerta al comité:</strong> con estos parámetros, la estrategia no mejora frente a no intervenir. Prueba aumentar recursos, bajar el contagio mediante reducción de contactos o revisar la zona inicial (${p.zone}). El sistema reporta el resultado aunque no favorezca la hipótesis.`;
 $("recommendation").innerHTML=msg;
 $("status").textContent=`Listo: ${p.runs} repeticiones por estrategia; ${p.n} personas sintéticas; semilla base ${p.seed}. Los rangos muestran mínimo–máximo observado, no intervalos de confianza.`;
}
$("runBtn").addEventListener("click",render);
$("resetBtn").addEventListener("click",()=>{Object.entries(defaults).forEach(([k,v])=>$(k).value=v);sliders.forEach(([id,out,fmt])=>$(out).textContent=fmt($(id).value));render();});
render();
})();