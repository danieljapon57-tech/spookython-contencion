# Contención Manta — SpookyThon 2026, Track B 🧟

Herramienta web educativa para simular la propagación de un brote en una población sintética y comparar tres políticas: no intervenir, proteger personas al azar y proteger primero a quienes tienen más conexiones. Está diseñada para explicar decisiones bajo recursos limitados; no es un pronóstico sanitario oficial.

## Probar localmente
1. Descarga o clona el repositorio.
2. Abre `index.html` en un navegador moderno. No requiere instalar paquetes, servidor, API keys ni base de datos.
3. Cambia población, contagio, contactos, incubación, duración infecciosa, recursos, zona inicial, semilla y repeticiones.
4. Pulsa **Ejecutar simulación**. La tabla presenta promedios y mínimos/máximos observados; la gráfica presenta la curva promedio de la estrategia priorizada.

## Modelo y supuestos
- Población sintética de `N` nodos conectados aleatoriamente. Cada nodo intenta crear hasta `k` conexiones por construcción; la red no representa contactos reales de Manta.
- Estados SEIR simplificados: susceptible/sano, expuesto, infeccioso y recuperado/inmune.
- El paciente cero se ubica en un índice que representa la zona elegida (hogar, colegio, bus o mercado). No se usan direcciones ni datos personales.
- Cada persona infecciosa intenta transmitir a sus vecinos con probabilidad `p` por día. La incubación y duración infecciosa son parámetros elegidos por el usuario.
- Intervención modelada: protección preventiva perfecta de hasta `K` personas elegibles antes del brote. En el modo inteligente se prioriza el grado (número de conexiones); en la línea aleatoria se eligen nodos aleatoriamente. La línea “sin intervenir” no protege a nadie.
- Los parámetros iniciales son valores didácticos para demostrar el método, no estimaciones clínicas. No se calibró con datos oficiales. Para una versión investigativa se deben incorporar datos abiertos, documentar su fecha/licencia y validar el modelo con asesoría epidemiológica.
- Se realizan repeticiones con semillas derivadas de la semilla base. La misma configuración produce los mismos resultados en el mismo navegador/versión del código. Los resultados son promedios y rangos mínimo–máximo observados, no intervalos de confianza.
- El modelo es deliberadamente explicable y no incluye movilidad real, edad, inmunidad parcial, mortalidad ni saturación hospitalaria.

## Reproducibilidad
Configuración por defecto: N=300, p=0.22, k=5, incubación=2 días, infeccioso=6 días, K=20, zona inicial=hogar, semilla=2026 y 50 repeticiones. En la demostración, el jurado puede cambiar la semilla y los parámetros. Los resultados dependen de los valores seleccionados.

## Despliegue en AWS (sitio estático)
Opción simple: AWS Amplify Hosting.
1. Crea un repositorio público en GitHub y sube todos los archivos de este proyecto.
2. En AWS Amplify, elige **Host web app / GitHub**, autoriza el repositorio y selecciona la rama principal.
3. Como es una web estática sin compilación, usa comandos de build vacíos o `echo "Static site"` y directorio de salida raíz `/` si la consola lo solicita. Si la consola no acepta raíz, usa Amazon S3 + CloudFront siguiendo la documentación oficial.
4. Espera a que Amplify indique despliegue exitoso y copia la URL HTTPS pública.
5. Abre la URL en una ventana privada y prueba que la simulación funcione.
6. Configura AWS Budget con alerta de costo desde el primer día y guarda una captura real en `docs/budget.png`. No subas claves, contraseñas ni datos de facturación.

La URL de AWS no existe hasta que el equipo realice el despliegue. No se incluye una URL ficticia.

## Arquitectura
Ver `docs/arquitectura.svg`. Flujo: navegador del usuario → Amplify Hosting (o S3 + CloudFront) → HTML/CSS/JavaScript estático. El cálculo se ejecuta en el navegador; no se envían datos personales ni se necesita backend. La web pública entrega solo los archivos estáticos.

## Costos
Ver `docs/costos.md`. No hay gasto de cómputo de simulación en servidor, porque se calcula en el dispositivo del usuario. El costo real debe verificarse en AWS Billing después del despliegue y declararse honestamente. Añadir captura real del AWS Budget en `docs/budget.png`.

## Seguridad y limitaciones
- No hay credenciales, secretos ni llaves de AWS en el repositorio.
- El sitio no recoge datos personales.
- Los resultados dependen de un modelo sintético y no deben usarse para decidir cierres, vacunación o atención médica reales.
- La estrategia por grado es una heurística sencilla; no garantiza vencer a la aleatoria en cada escenario. Si no gana en la prueba sorpresa, expliquen el resultado y ajusten parámetros/intervención sin ocultar resultados.

## Estructura
- `index.html`: interfaz.
- `src/app.js`: simulación reproducible, estrategias, métricas y gráfica.
- `src/styles.css`: diseño adaptable.
- `docs/arquitectura.svg`: diagrama de arquitectura.
- `docs/costos.md`: supuestos de costos.

## Créditos
Prototipo académico elaborado para SpookyThon 2026 — Track B: La Plaga Zombie.
